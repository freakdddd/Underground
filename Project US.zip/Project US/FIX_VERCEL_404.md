# 🔧 Cara Fix Error 404 di Vercel

## Masalah: 404 NOT_FOUND di Vercel

Ini biasanya terjadi karena:
- File tidak ter-upload dengan benar
- Struktur folder salah
- File index.html tidak di root

## ✅ SOLUSI (Ikuti Langkah Ini):

### Opsi 1: Re-deploy di Vercel (Paling Mudah)

1. **Buka Vercel Dashboard**: https://vercel.com/dashboard
2. **Hapus project yang error** (jika ada):
   - Klik project "underground-vert"
   - Klik "Settings" → scroll ke bawah → "Delete Project"
3. **Buat project baru**:
   - Klik "Add New Project"
   - Pilih tab **"Upload"**
   - **PENTING**: Jangan drag folder, tapi pilih file satu per satu:
     - Klik "Select Files" atau drag file-file berikut:
       - `index.html`
       - `style.css`
       - `logo.png`
       - `arle.png`
       - `Atan.png`
       - `Diki.png`
       - `Gerald.png`
   - **JANGAN** upload folder "Project US", tapi file-file di dalamnya
4. **Klik "Deploy"**
5. **Tunggu sampai selesai** (sekitar 1-2 menit)
6. **Cek URL baru** yang diberikan Vercel

### Opsi 2: Zip Folder Lalu Upload

1. **Buat ZIP file**:
   - Klik kanan folder "Project US"
   - Pilih "Compress" (di Mac) atau "Send to → Compressed folder" (di Windows)
   - Akan terbuat file `Project US.zip`
2. **Upload ke Vercel**:
   - Buka https://vercel.com/dashboard
   - Hapus project lama (jika ada)
   - Klik "Add New Project" → "Upload"
   - Drag file `Project US.zip` ke area upload
   - Vercel akan otomatis extract ZIP-nya
   - Klik "Deploy"

### Opsi 3: Gunakan Netlify (Lebih Mudah & Jarang Error)

Jika Vercel masih error, coba Netlify:

1. **Buka**: https://www.netlify.com
2. **Login** (bisa pakai Google)
3. **Drag & Drop**:
   - Klik "Add new site" → "Deploy manually"
   - **Drag seluruh folder "Project US"** ke area tersebut
   - Atau zip folder dulu, lalu drag ZIP-nya
4. **Tunggu deploy** (sekitar 1 menit)
5. **Website langsung online!**

---

## ⚠️ PENTING: Pastikan File Struktur Benar

Saat upload ke Vercel, pastikan struktur seperti ini:

```
(root)
├── index.html      ← HARUS ada di root
├── style.css       ← HARUS ada di root
├── logo.png
├── arle.png
├── Atan.png
├── Diki.png
├── Gerald.png
└── img/            ← folder (boleh kosong)
```

**JANGAN** upload seperti ini:
```
Project US/         ← JANGAN ada folder wrapper
  └── index.html
```

**HARUS** upload langsung file-file di root:
```
index.html          ← Langsung di root
style.css
logo.png
...
```

---

## 🎯 Langkah Cepat (Recommended):

1. **Buka Vercel Dashboard**: https://vercel.com/dashboard
2. **Hapus project lama** (jika ada)
3. **Klik "Add New Project" → "Upload"**
4. **Pilih SEMUA file** di folder "Project US" (Ctrl/Cmd + A, lalu drag)
5. **Klik "Deploy"**
6. **Tunggu dan cek URL baru**

---

## ✅ Setelah Deploy Berhasil:

Website akan bisa diakses dengan URL seperti:
- `underground-vert-xxx.vercel.app` (URL baru)
- Atau bisa rename di Settings → General → Project Name

---

**Jika masih error, coba Netlify - biasanya lebih mudah dan jarang error! 🚀**

